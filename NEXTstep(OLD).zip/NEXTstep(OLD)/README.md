# NEXTStep
 Platform with online personal trainers in mind
 Originally i was going to build a React+Express+MongoDB app called NEXTStep, but I decided to switch to upSTEP (though i might keep the old name, it looks better) which is a light React+Vite app with just Python and SQLAlchemy on my backend
